package database;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import movie.Movie;


public class Database {
	// Create a hash map
    private HashMap<String, Movie> movieList = new HashMap<String, Movie>();
   
    int entryInt = 0;
    
    //Add movie constructor
    public void addMovie(String title, String genre, double costPerDay, int maxRentalDays, char status) {
    	entryInt++;
    	String entry = String.format("%05d", entryInt);
    	movieList.put(entry, new Movie(title, genre, costPerDay, maxRentalDays, status));	
    }
    
    //Accessor to return HashMap of movies
    public HashMap getMovieList(){
    	return this.movieList;
    }
    
    //Accessor to return Movie within a HashMap
    public Movie getMovie(String entry) {
    	return (movieList.get(entry));
    }
	
}
