package database;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import movie.Movie;


public class Database {
	// Create a hash map
    private HashMap<String, Movie> movieList = new HashMap<String, Movie>();
    String movieID;
    
    public void addMovie(String title, String genre, double costPerDay, int maxRentalDays, char status) {
    	movieID = UUID.randomUUID().toString();
    	movieList.put(movieID, new Movie(title, genre, costPerDay, maxRentalDays, status));	
    }
    
    public void buildMovieList(HashMap movieList) {
		System.out.printf("%-25s%s\n","Movie Title","Availability");
		// Get a set of the entries
	      Set set = movieList.entrySet();
	      // Get an iterator
	      Iterator i = set.iterator();
	      // Display elements
	      while(i.hasNext()) {
	         Map.Entry movie = (Map.Entry)i.next();
	         System.out.printf("%-25s%s\n",movie.getKey(),movie.getKey());
	         System.out.println(movie.getValue());
	      }
	}
    
    public HashMap getMovieList(){
    	return this.movieList;
    }
    public Movie getMovie(String movieID) {
    	return (movieList.get(movieID));
    }
	
}
