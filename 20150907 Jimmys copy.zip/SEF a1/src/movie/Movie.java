package movie;

import java.util.UUID;

public class Movie {
	private String title;
	private String genre;
	private double costPerDay; //cost of rental per day
	private int maxRentalDays;//cap on days available to rent. Once this threshold is reached, fine customer
	private char status; //A == Available, B == Booked, R == Reserved
	private int copies = 0;//**TO BE IMPLEMENTED** this variable will need to be moved to database. Made to represent total copies owned by the vid store
	String movieID; //unique ID
	
	//Main movie constructor
	public Movie(String title, String genre, double costPerDay, int maxRentalDays, char status)
	{
		this.title = title;
		this.genre = genre;
		this.costPerDay = costPerDay; //Cost of renting a movie by the day
		this.maxRentalDays = maxRentalDays; 
		this.status = 'A'; //initialize to available. **NOTE** Will need to be setable once 'reservations' on new titles made.
		this.copies++;  
		movieID = UUID.randomUUID().toString(); //unique ID. To be used at a later time to ensure unique copies
	}
	
	public void printBasicMovie() { //testing purposes
		System.out.println(this.title);
		System.out.println(this.status);
	}
	
	//Movie mutators
	public void setTitle(String title)
	{
		this.title = title;
	}
	public void setGenre(String Genre)
	{
		this.genre = genre;
	}
	public void setCostPerDay(double costPerDay)
	{
		this.costPerDay = costPerDay;
	}
	public void maxRentalDays(int maxRentalDays)
	{
		this.maxRentalDays = maxRentalDays;
	}
	
	//Movie accessors
	public String getTitle()
	{
		return this.title;
	}
	public String getGenre()
	{
		return this.genre;
	}
	public double getCostPerDay()
	{
		return this.costPerDay;
	}
	public double getMaxRentalDays()
	{
		return this.maxRentalDays;
	}
	public char getStatus()
	{
		return this.status;
	}
}
