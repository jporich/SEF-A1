package movie;

public class Movie {
	private String title;
	private String genre;
	private double costPerDay; //cost of rental per day
	private int maxRentalDays;
	private char status; //A == Available, B == Booked, R == Reserved
	private int copies = 0;
	
	public Movie(String title, String genre, double costPerDay, int maxRentalDays, char status)
	{
		this.title = title;
		this.genre = genre;
		this.costPerDay = costPerDay;
		this.maxRentalDays = maxRentalDays;
		this.status = 'A'; //initialize to available.
		this.copies++;
	}
	
	public void printBasicMovie() {
		System.out.println(this.title);
		System.out.println(this.status);
	}
	
	//mutators
	public void setTitle(String title)
	{
		this.title = title;
	}
	public void setGenre(String Genre)
	{
		this.genre = genre;
	}
	public void setCostPerDay(double costPerDay)
	{
		this.costPerDay = costPerDay;
	}
	public void maxRentalDays(int maxRentalDays)
	{
		this.maxRentalDays = maxRentalDays;
	}
	
	//accessors
	public String getTitle()
	{
		return this.title;
	}
	public String getGenre()
	{
		return this.genre;
	}
	public double getCostPerDay()
	{
		return this.costPerDay;
	}
	public double getMaxRentalDays()
	{
		return this.maxRentalDays;
	}
}
