package rentalSys;

import menu.Menu;
import database.Database;

public class RentalSys {

	public static void main(String[] args) {
		//Instantiate movie database
		Database movieDB = new Database();
		
		movieDB.addMovie("Avengers", "Action", 3.5, 2, 'A');
		//Instantiate menus

		Menu mainMenu = new Menu();
		mainMenu.buildMainMenu();
		Menu.displayMainMenu(mainMenu);

	}

}
