package menu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import database.Database;

public class Menu {
	// Create basic menu as an arraylist. Add options depending on type of menu. In this way program becomes scalable for further options easily
	private ArrayList<String> options = new ArrayList<String>();
	
	//scanner for user input
	private static Scanner input = new Scanner(System.in);
	private static int option;
	
	//options for main menu
	public void buildMainMenu() {
		options.add("1. View Movies");
		options.add("0. Exit");
	}
	
	//options for movie menu.
	public void buildMovieMenu() {
		options.add("1. View movie details");
		options.add("2. Rent movie");
		options.add("0. Return to main menu");
	}
	
	//clear all movie options, ready to populate menu with whichever menu needs loading
	public void clearMenu() {
		options.clear();
	}
	
	//display the main menu. take menu as argument so it can populate based on type of menu inputed, also takes movie DB to pass on to the movie list menu
	public static void displayMainMenu(Menu mainMenu, Database movieList) {
		for (int i = 0; i < mainMenu.options.size(); i++) {
			System.out.println(mainMenu.options.get(i));
		}
		System.out.println("\n\nSelect option:");
		option = input.nextInt();
		System.out.println();
		System.out.println("You selected " + option);//debugging purposes
		System.out.println();
		switch (option) {
		case 1:
			mainMenu.clearMenu();
			mainMenu.buildMovieMenu();
			mainMenu.displayMovieMenu(mainMenu, movieList);
			break;
		case 0:
			System.out.println("You are now exiting Mockbuster Video system.");
			System.exit(0);
		}
	}
	
	//displaying movie menu. Takes menu class as argument, also take Database object so it can read values from DB
	public static void displayMovieMenu(Menu movieMenu, Database movieList) {
		System.out.printf("%-25s%s\n", "Movie Title", "Availability");
		// Make a set of hashmap values
		Set set = movieList.getMovieList().entrySet();
		// Make an iterator for the set
		Iterator i = set.iterator();
		// iterative over the set. Print out basic view of all movies (list no, title, availability)
		while (i.hasNext()) {
			Map.Entry newList = (Map.Entry) i.next();
			System.out.printf("%-5s%-25s%s\n", newList.getKey(), movieList.getMovie((newList.getKey()).toString()).getTitle(), movieList.getMovie((newList.getKey()).toString()).getStatus());
			System.out.println();
			
		}
		//go through movie options list. Print out values for each option
		for (int j = 0; j < movieMenu.options.size(); j++) {
			System.out.println(movieMenu.options.get(j));
		}
		System.out.println("\n\nSelect option:");
		option = input.nextInt();
		System.out.println();
		System.out.println("You selected " + option);
		switch (option) {
		case 1://case 1, user selects movie to view details
			System.out.println("**TO IMPLEMENT**Please enter the movieID of the movie you wish to view");
			break;
		case 2://case 2, user wish to rent movie without looking at further details
			System.out.println("**TO IMPLEMENT**Please enter the movieID of the movie you wish to rent");
			break;
		case 0://return to main menu. Clear out all options, repopulate them with main menu options
			System.out.println("Returning to main menu.");
			movieMenu.clearMenu();
			movieMenu.buildMainMenu();
			movieMenu.displayMainMenu(movieMenu, movieList);
			break;
		}

	}
}
