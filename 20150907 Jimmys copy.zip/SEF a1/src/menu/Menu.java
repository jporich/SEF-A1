package menu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Menu {
	//Create basic menu as an arraylist. Add options depending on type of menu.
	private ArrayList<String> options = new ArrayList<String>();
	
	private static Scanner input = new Scanner(System.in);
	private static int  option;
	
	public void buildMainMenu() {
		options.add("1. View Movies");
		options.add("0. Exit");
	}
	
	public void buildMovieMenu() {
		options.add("1. View movie details");
		options.add("2. Rent movie");
		options.add("0. Return to main menu");
	}
	public void clearMenu() {
		options.clear();
	}
	
	public static void displayMainMenu (Menu mainMenu){
		for (int i = 0 ; i < mainMenu.options.size() ; i++){
			System.out.println(mainMenu.options.get(i));
		}
		System.out.println("\n\nSelect option:");
		option = input.nextInt();
		
		System.out.println("You selected " + option);
		switch (option) {
		case 1:
			mainMenu.clearMenu();
			mainMenu.buildMovieMenu();
			mainMenu.displayMovieMenu(mainMenu);
			break;
		case 0:
			System.out.println("You are now exiting Mockbuster Video system.");
			System.exit(0);
		}
	}
	
	public static void displayMovieMenu (Menu movieMenu) {
		for (int i = 0 ; i < movieMenu.options.size() ; i++){
			System.out.println(movieMenu.options.get(i));
		}
		System.out.println("\n\nSelect option:");
		option = input.nextInt();
		
		System.out.println("You selected " + option);
		switch (option) {
		case 1:
			System.out.println("**TO IMPLEMENT**Please enter the movieID of the movie you wish to list");
			
			break;
		case 0:
			System.out.println("Returning to main menu.");
			movieMenu.clearMenu();
			movieMenu.buildMainMenu();
			movieMenu.displayMainMenu(movieMenu);
		}
		
	}
}
